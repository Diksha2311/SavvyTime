import React,{ useState, useEffect, useRef } from "react";

import { useNavigate } from "react-router-dom";
import { Loader2, Search, Repeat, Globe, MapPin, Sun, Check, Clock, Plus, X } from "lucide-react";

// --- DashboardCards Component ---
const cardsData = [
  {
    id: 1,
    icon: <Repeat className="text-indigo-500" size={24} />,
    title: "Time Converter",
    description: "Easily convert times between different time zones for meetings and events.",
    linkText: "Open Converter",
    linkHref: "#",
  },
  {
    id: 2,
    icon: <Globe className="text-indigo-500" size={24} />,
    title: "Time Around the World",
    description: "View current local times in major cities and regions globally.",
    linkText: "Explore World Clock",
    linkHref: "#",
  },
  {
    id: 3,
    icon: <MapPin className="text-white" size={24} />,
    title: "Your Location",
    description: "We've detected you are currently in ",
    location: "New York, USA",
    time: "10:42",
    period: "AM",
    timezone: "EDT (UTC-4)",
    weatherIcon: <Sun size={20} className="text-amber-400" />,
  },
];

const DashboardCards = () => {
  return (
    <div className="w-full mt-10">
      <div className="grid w-full grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 px-4 sm:px-8 lg:px-16 mt-20">
        {cardsData.map((card) => (
          <div
            key={card.id}
            className={`
              p-8 rounded-2xl shadow-md border
              ${card.id === 3
                ? "bg-[#111827] text-white border-gray-200 dark:border-gray-700"
                : "bg-white dark:bg-[#161a35] border-gray-200 dark:border-gray-700"
              }
              transform transition duration-300 hover:shadow-xl hover:scale-[1.03]
              flex flex-col justify-between min-h-[320px] lg:min-h-[350px] relative
            `}
          >
            <div>
              <div className="flex items-center mb-8">
                <div className={`${card.id === 3 ? "p-3 bg-white/10 rounded-xl" : ""}`}>
                  {card.icon}
                </div>
              </div>
              <h3 className="text-xl lg:text-2xl font-bold mb-3">{card.title}</h3>
              <p className={`text-base lg:text-lg leading-relaxed ${card.id === 3 ? "text-white/80" : "text-gray-600 dark:text-gray-300"}`}>
                {card.description} <strong>{card.location}</strong>
              </p>
            </div>

            {card.id === 3 ? (
              <div className="mt-auto">
                <div className="w-full h-[1px] bg-white/10 mb-6 mt-4" />
                <div className="flex items-center justify-between">
                  <div className="flex flex-col">
                    <div className="flex items-baseline">
                      <span className="text-4xl lg:text-5xl font-bold">{card.time}</span>
                      <span className="ml-2 text-xl font-medium opacity-70">{card.period}</span>
                    </div>
                    <p className="text-sm opacity-50 mt-1 uppercase tracking-wider">{card.timezone}</p>
                  </div>
                  <div className="text-amber-400">
                    {React.cloneElement(card.weatherIcon as React.ReactElement, { size: 30 })}
                  </div>
                </div>
              </div>
            ) : (
              <a href={card.linkHref} className="text-blue-600 dark:text-blue-400 text-base lg:text-lg font-medium hover:underline mt-4 inline-block">
                {card.linkText} →
              </a>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

// --- Main Home Component ---
export default function Home() {
  const navigate = useNavigate();
  const [currentTime, setCurrentTime] = useState("");
  const [is24Hour, setIs24Hour] = useState(false);
  const [search, setSearch] = useState("");
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [addedCities, setAddedCities] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  
  // Ref for the search container
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Click Outside Listener
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSearch = async (val: string) => {
    setSearch(val);
    if (val.trim().length > 0) {
      setShowDropdown(true);
      setIsLoading(true);
      try {
        const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${val}&count=5&language=en&format=json`);
        const data = await res.json();
        if (data.results) {
          const formatted = data.results.map((city: any) => {
            const cityTime = new Intl.DateTimeFormat("en-US", {
              hour: "numeric", minute: "numeric", hour12: true, timeZone: city.timezone,
            }).format(new Date());
            return {
              id: city.id,
              name: city.name,
              country_code: city.country_code,
              info: `${city.admin1 ? city.admin1 + ", " : ""}${city.country}`,
              time: cityTime.toLowerCase(),
              timezone: city.timezone,
              lat: city.latitude,
              lng: city.longitude,
            };
          });
          setSuggestions(formatted);
        } else {
          setSuggestions([]);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    } else {
      setSuggestions([]);
      setShowDropdown(false);
    }
  };

const onAddCity = async (city: any) => {
  setAddedCities((prev) => {
  if (prev.some(c => c.id === city.id)) return prev;
  return [...prev, city];
});

  console.log("Adding city:", city); 
  setIsLoading(true);
  setShowDropdown(false);
  
  try {
    // 1. Country details fetch karein
    const countryRes = await fetch(`https://restcountries.com/v3.1/alpha/${city.country_code}`);
    const countryData = await countryRes.json();
    const cInfo = countryData[0];
    
    // 2. Consistent String ID (IND42)
    const customId = city.name.slice(0, 3).toUpperCase() + Math.floor(Math.random() * 100);


// --- NEW: Currency Logic ---
    let displayCurrency = "N/A";
    if (cInfo && cInfo.currencies) {
      const currencyKey = Object.keys(cInfo.currencies)[0]; // e.g. "INR"
      const cur = cInfo.currencies[currencyKey];
      displayCurrency = `${cur.name} ${cur.symbol ? `(${cur.symbol})` : ""}`;
    }


    // 3. Timezone offset logic
    let offsetPart = "GMT+0";
    try {
      const formatter = new Intl.DateTimeFormat('en-US', { 
        timeZone: city.timezone, 
        timeZoneName: 'shortOffset' 
      });
      offsetPart = formatter.formatToParts(new Date()).find(p => p.type === 'timeZoneName')?.value || "GMT+0";
    } catch {
      offsetPart = "GMT+5:30"; // Fallback for India
    }

    // 4. Object Mapping (FIXED KEYS)
    const newCityData = {
      id: customId,
      city: city.name,
      country: cInfo?.name?.common || city.country || "Unknown",
      countryCode: city.country_code.toUpperCase(),
      timezone: city.timezone || "Asia/Kolkata",
      offset: offsetPart,
currency: displayCurrency,
coords: `${city.lat?.toFixed(2) || "0.00"}° N, ${city.lng?.toFixed(2) || "0.00"}° E`,

      language: cInfo?.languages ? Object.values(cInfo.languages).join(", ") : "Hindi/English",
      dialing: (cInfo?.idd?.root || "") + (cInfo?.idd?.suffixes ? cInfo.idd.suffixes[0] : ""),
      iana: city.timezone || "Asia/Kolkata",
      image: `https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80&sig=${customId}`,
      description: `${city.name} is a major city.`
    };

    console.log("Navigating with data:", newCityData);
    navigate("/city", { state: { tempCity: newCityData } });

  } catch (error) {
    console.error("Critical Error in onAddCity:", error);
    // Emergency Fallback taaki button click hamesha kaam kare
    const fallbackId = city.name.slice(0, 3).toUpperCase() + "00";
    navigate("/city", { 
      state: { 
        tempCity: { 
          id: fallbackId, 
          city: city.name, 
          countryCode: city.country_code?.toUpperCase() || "IN",
          timezone: city.timezone || "Asia/Kolkata"
        } 
      } 
    });
  } finally {
    setIsLoading(false);
    setSearch("");
  }
};

  // Clock Logic
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, "0");
      const seconds = now.getSeconds().toString().padStart(2, "0");
      const ampm = hours >= 12 ? "PM" : "AM";
      const displayHours = !is24Hour ? hours % 12 || 12 : hours;
      setCurrentTime(`${displayHours}:${minutes}:${seconds}${!is24Hour ? " " + ampm : ""}`);
    }, 1000);
    return () => clearInterval(interval);
  }, [is24Hour]);

  const today = new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" });
  const timeParts = currentTime.match(/(\d+:\d+):(\d+)\s?(AM|PM)?/i);
  const hoursMinutes = timeParts ? timeParts[1] : "";
  const secondsDisplay = timeParts ? timeParts[2] + (timeParts[3] ? " " + timeParts[3] : "") : "";

  return (
    <div className="min-h-screen w-full flex flex-col bg-[#E9EDFA] dark:bg-[#0B1224] text-slate-800 dark:text-white">
      <main className="flex-1 flex justify-center px-4 sm:px-6 lg:px-12">
        <div className="w-full flex flex-col items-center space-y-10 mt-10">
          
          <div className="flex items-center px-3 bg-white/50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-3xl w-max">
            <span className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
            <span className="text-slate-500 dark:text-slate-400 text-sm font-medium">SYNCHRONIZED WORLDWIDE</span>
          </div>

          <div className="text-center max-w-5xl">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold">
              <span className="block">Time conversion,</span>
              <span className="block text-purple-400 mt-2">simplified.</span>
            </h1>
            <p className="mt-6 text-base sm:text-lg lg:text-xl text-gray-500">
              Instantly convert time zones across the globe with professional precision.
            </p>
          </div>

          {/* --- Updated Search Section --- */}
          <div ref={searchContainerRef} className="w-full max-w-xl mt-6 relative group/searchbox">
            <div className="relative flex items-center shadow-sm mt-6">
              <div className="absolute left-0 pl-4 flex items-center pointer-events-none">
                {isLoading ? <Loader2 size={18} className="animate-spin text-purple-500" /> : <Search size={20} className="text-slate-500" />}
              </div>
              <input
                type="text"
                value={search}
                onFocus={() => search.length > 0 && setShowDropdown(true)}
                onChange={(e) => handleSearch(e.target.value)}
                placeholder="Search for a city or time zone..."
                className="w-full rounded-full pl-12 pr-16 py-3 bg-white dark:bg-[#161a35] text-slate-900 dark:text-white border border-slate-400 dark:border-white/20 focus:outline-none focus:border-blue-400 text-lg transition-all"
              />
              <div onClick={() => suggestions.length > 0 && onAddCity(suggestions[0])} className="absolute right-0 top-0 bottom-0 px-4 flex items-center cursor-pointer rounded-r-full">
                <Plus size={22} className="text-slate-400 hover:text-blue-500 active:scale-90 transition-all" strokeWidth={2.5} />
              </div>
            </div>

            {/* Dropdown Logic */}
            {showDropdown && search.length > 0 && (
              <div className="mt-2 absolute w-full bg-white dark:bg-[#161a35] border border-slate-300 dark:border-white/20 shadow-2xl z-50 rounded-2xl overflow-hidden">
                {suggestions.length > 0 ? (
                  suggestions.map((city) => (
                    <div
                      key={city.id}
                      onClick={() => onAddCity(city)}
                      className="px-4 py-3 hover:bg-blue-50 dark:hover:bg-white/5 cursor-pointer flex justify-between items-center group border-b border-slate-100 dark:border-white/5 last:border-0"
                    >
                      <div className="text-sm">
                        <span className="font-bold text-slate-800 dark:text-slate-100">{city.name}</span>
                        <span className="ml-1 text-slate-500">({city.info})</span>
                      </div>
                      <span className="text-xs text-slate-500 font-medium group-hover:text-blue-500">{city.time}</span>
                    </div>
                  ))
                ) : (
                  <div className="px-4 py-6 text-center text-gray-400 italic text-sm">City not found</div>
                )}
              </div>
            )}
          </div>

          <div className="w-full max-w-xl flex flex-wrap gap-2">
            {addedCities.map(city => (
              <div key={city.id} className="flex items-center gap-2 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 px-3 py-1 rounded-full text-xs font-bold border border-blue-200 dark:border-blue-800">
                {city.name}
                <X size={14} className="cursor-pointer" onClick={() => setAddedCities(addedCities.filter(c => c.id !== city.id))} />
              </div>
            ))}
          </div>

     {/* 12h | 24h Toggle - Positioned slightly before the end */}
          <div className="flex justify-end ml-60 mt-8 ">
            <div className="flex items-center gap-2 text-[15px] font-black tracking-widest text-slate-400 dark:text-white/30 uppercase select-none">
              <span
                className={`transition-all duration-200 ${!is24Hour
                  ? "text-indigo-600 dark:text-indigo-400 scale-110"
                  : "cursor-pointer hover:text-slate-600 dark:hover:text-white/60"
                  }`}
                onClick={() => setIs24Hour(false)}
              >
                12h
              </span>

              <span className="opacity-50 font-gray">|</span>

              <span
                className={`transition-all duration-200 ${is24Hour
                  ? "text-indigo-600 dark:text-indigo-400 scale-110"
                  : "cursor-pointer hover:text-slate-600 dark:hover:text-white/60"
                  }`}
                onClick={() => setIs24Hour(true)}
              >
                24h
              </span>
            </div>
          </div>

          <div className="w-full max-w-4xl px-4 py-4">
            <div className="flex flex-col lg:flex-row justify-center items-center lg:items-baseline">
              <span className="text-6xl sm:text-8xl md:text-9xl lg:text-[8rem] font-bold leading-none">{hoursMinutes}</span>
              {secondsDisplay && (
                <span className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl lg:ml-4 text-slate-400 font-medium mt-2 lg:mt-0">{secondsDisplay}</span>
              )}
            </div>
            <div className="mt-6 text-center">
              <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-medium text-gray-700 dark:text-gray-300">{today}</h2>
            </div>
          </div>

          <DashboardCards />

 <div className="flex justify-center px-4 sm:px-6 lg:px-12">
            {/* Outer Box */}
            <div className="
    w-full
    max-w-5xl
    text-center
    px-6 sm:px-10 lg:px-16
    py-8 sm:py-10 lg:py-12
    border border-[rgb(var(--border-main))]
    rounded-2xl
  ">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold">
                Stay in sync, everywhere.
              </h1>

              <p className="mt-4 sm:mt-6 text-sm sm:text-base lg:text-lg text-gray-400 leading-relaxed">
                Join thousands of remote teams who trust ChronoSync for their global scheduling needs. Simple, fast, and always accurate.
              </p>

              {/* Get Started + Learn more */}
              <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
                {/* Get Started Button */}
                <button className="
  px-6 sm:px-8 py-2.5 sm:py-3
  rounded-xl
  font-bold text-sm tracking-[0.2em] uppercase
  transition-all duration-300
  
  /* Background & Text */
  bg-[#131A2E] text-white
  border border-white/10
  
  /* Hover & Glow Effects */
  hover:bg-[#1a2440]
  hover:border-indigo-500/50
  hover:shadow-[0_0_20px_rgba(19,26,46,0.8)]
  
  /* Responsive interaction */
  active:scale-95
">
                  Get Started
                </button>

                {/* Learn more link */}
                <a href="#" className="
        text-gray-400
        font-medium
        flex items-center gap-1
        hover:underline hover:text-blue-500
        transition
        text-sm sm:text-base
      ">
                  Learn more <span className="text-lg">→</span>
                </a>
              </div>

              {/* Features */}
              <div className="mt-6 sm:mt-10 flex flex-col sm:flex-row items-center justify-center gap-6 text-[11px] sm:text-xs font-bold tracking-widest uppercase text-slate-500 dark:text-slate-400">

                {/* No Sign up required */}
                <div className="flex items-center gap-2 group cursor-default">
                  <div className="flex items-center justify-center w-5 h-5 rounded-full bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 group-hover:border-indigo-500/50 transition-colors">
                    <Check size={12} className="text-gray-600 dark:text-gray-400" strokeWidth={3} />
                  </div>
                  <span className="opacity-80 group-hover:opacity-100 transition-opacity">No Sign up required</span>
                </div>
   <div className="flex items-center gap-2 group cursor-default">
                  <div className="flex items-center justify-center w-5 h-5 rounded-full bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 group-hover:border-indigo-500/50 transition-colors">
                    <Check size={12} className="text-gray-600 dark:text-gray-400" strokeWidth={3} />
                  </div>
                  <span className="opacity-80 group-hover:opacity-100 transition-opacity">Free Forever</span>
                </div>
               

              </div>
            </div>
          </div>


          {/* Popular Quick Conversion */}
          <div className="mt-10 text-center">
            {/* Heading */}


            <p className=" mb-8 mt-8 text-[14px] font-bold tracking-widest text-slate-700 dark:text-slate-500 uppercase">
              Popular Quick Conversion
            </p>

            {/* Buttons */}
            <div className="w-full flex flex-col items-center gap-3 px-4">
              {/* Row 1: 8 Buttons (Responsive Grid) */}
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 w-full max-w-screen-xl ">
                {[
                  "EST to IST", "GMT to EST", "PST to EST", "EST to GMT",
                  "PST to GMT", "IST to EST", "GMT to IST", "EST to PST"
                ].map((item) => (
                  <button key={item} className="px-3 py-2 text-[10px] sm:text-xs font-medium rounded-full border border-gray-400 text-[rgb(var(--text-main))] hover:text-blue-500 hover:border-blue-500 transition truncate">
                    {item}
                  </button>
                ))}
              </div>

              {/* Row 2: 4 Buttons (Centered & Responsive) */}
              <div className="grid grid-cols-2 sm:flex sm:flex-wrap  font-medium justify-center gap-3 w-full max-w-screen-xl">
                {[
                  "IST to GMT", "GMT to PST", "CST to IST", "IST to CST"
                ].map((item) => (
                  <button
                    key={item}
                    className="
          px-3 py-2 text-[10px] sm:text-xs rounded-full border 
          border-gray-400 text-[rgb(var(--text-main))]
          hover:text-blue-500 hover:border-blue-500 transition 
          sm:min-w-[140px] lg:w-auto truncate
        "
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="mt-20 border-t border-slate-300 dark:border-white/5 bg-[#E9EDFA] dark:bg-[#0B1224]  transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-6 py-10">
          <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-6">

            {/* LEFT SECTION: Logo */}
            <div className="flex items-center gap-2 group cursor-pointer">
              <div className="pbg-gray-500 rounded-lg group-hover:rotate-12 transition-transform duration-300">
                <Clock size={18} className="text-gray" />
              </div>
              <span className="font-black text-lg  text-slate-900 dark:text-gray-600 uppercase">
                CHRONOSYNC
              </span>
            </div>

            {/* RIGHT SECTION: Vertically Stacked & Right Aligned */}
            <div className="flex flex-col items-center md:items-end gap-2 text-right">

              {/* Row 1: Copyright */}
              <p className="text-[10px] font-bold tracking-widest text-slate-500 dark:text-slate-500 uppercase">
                © 2026 ChronoSync Inc. All rights reserved.
              </p>

              {/* Row 2: Navigation Links (Isse justify-end aur w-full diya hai taaki center se hat jaye) */}
              <div className="flex items-center justify-center md:justify-center gap-6 w-full text-[11px] font-black tracking-[0.15em] uppercase text-slate-600 dark:text-slate-400">
                {["Privacy", "Terms", "API"].map((item) => (
                  <a
                    key={item}
                    href={`#${item.toLowerCase()}`}
                    className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors relative group whitespace-nowrap"
                  >
                    {item}
                    <span className="absolute -bottom-1 left-0 w-0 h-[1.5px] bg-indigo-500 transition-all duration-300 group-hover:w-full" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
}













