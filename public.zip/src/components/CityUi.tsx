import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  MapPin,
  Sun,
  Moon,
  Sunset,
  Sunrise,
  Play,
  Pause,
  Plus,Globe,Phone,Clock,Banknote,
  Languages,Search,X

} from "lucide-react";

/* ================= CITY DATA ================= */
const cities = [
  {
    id: "IST",
    city: "New Delhi",
    country: "India",
    countryCode: "IN",
    timezone: "Asia/Kolkata",
    offset: "GMT+5:30",
    coords: "28.6139° N, 77.2090° E",
    currency: "Indian Rupee (INR)",
    language: "Hindi, English",
    dialing: "+91",
    iana: "Asia/Kolkata",
    sunrise: "06:23 AM",
    sunset: "06:45 PM",
    description:
      "India Standard Time (IST) is the standard time for New Delhi, India. This timezone does not observe daylight saving time.",
  },
  {
    id: "EST",
    city: "New York",
    country: "USA",
    countryCode: "US",
    timezone: "America/New_York",
    offset: "GMT-5:00",
    coords: "40.7128° N, 74.0060° W",
    currency: "US Dollar (USD)",
    language: "English",
    dialing: "+1",
    iana: "America/New_York",
    sunrise: "07:12 AM",
    sunset: "04:50 PM",
    image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9",
    description: "Eastern Standard Time (EST) is used in New York. It is a major global hub for finance, culture, and entertainment.", // New York image
  },
  {
    id: "GMT",
    city: "London",
    country: "UK",
    countryCode: "GB",
    timezone: "Europe/London",
    offset: "GMT+0:00",
    coords: "51.5074° N, 0.1278° W",
    currency: "British Pound (GBP)",
    language: "English",
    dialing: "+44",
    iana: "Europe/London",
    sunrise: "08:02 AM",
    sunset: "04:15 PM",
    image: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad",
    description: "Greenwich Mean Time (GMT) is the time at the Royal Observatory in Greenwich, London. It is the basis of every time zone.",
  },
  {
    id: "JST",
    city: "Tokyo",
    country: "Japan",
    countryCode: "JP",
    timezone: "Asia/Tokyo",
    offset: "GMT+9:00",
    coords: "35.6762° N, 139.6503° E",
    currency: "Japanese Yen (JPY)",
    language: "Japanese",
    dialing: "+81",
    iana: "Asia/Tokyo",
    sunrise: "06:45 AM",
    sunset: "04:55 PM",
    image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf",
    description: "Japan Standard Time (JST) is the standard time zone in Japan. Tokyo is famous for its mix of modern neon and ancient temples.",
  },
];


interface City {
  id: string;
  city: string;
  country: string;
  countryCode: string;
  timezone: string;
  offset: string;
  coords: string;
  currency: string;
  language: string;
  dialing: string;
  iana: string;
  sunrise: string;
  sunset: string;
  image: string;
  description: string;
}

/* ================= HELPERS ================= */
const getCityTime = (timezone: string) => {
  try {
    const now = new Date(new Date().toLocaleString("en-US", { timeZone: timezone }));
    return {
      time: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      date: now.toLocaleDateString(),
      hour: now.getHours(),
    };
  } catch  {
    return { time: "00:00", date: "--", hour: 0 };
  }
};
/* ================= PAGE ================= */
export default function CityUi() {
  const location = useLocation();
  const [isPaused, setIsPaused] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [progress, setProgress] = useState(0);
  // const [_currentTime, setCurrentTime] = useState<string>("");
  const [citiesList, setCitiesList] = useState(cities);
  const [selectedCity, setSelectedCity] = useState(cities[0]);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
const [searchResults, setSearchResults] = useState<any[]>([]);
const [isLoading, setIsLoading] = useState(false);

// Search API Logic
useEffect(() => {
  const fetchCities = async () => {
    if (searchQuery.length < 3) {
      setSearchResults([]);
      return;
    }
    setIsLoading(true);
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?city=${encodeURIComponent(searchQuery)}&format=json&addressdetails=1&limit=5`
      );
      const data = await response.json();
      setSearchResults(data);
    } catch (error) {
      console.error("Search failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const timer = setTimeout(fetchCities, 500); // 0.5s debounce
  return () => clearTimeout(timer);
}, [searchQuery]);




  useEffect(() => {
    if (location.state && location.state.tempCity) {
      const newCity = location.state.tempCity;
      
      setCitiesList((prev) => {
        const isExist = prev.find((c) => c.id === newCity.id);
        if (!isExist) {
          const updatedList = [...prev, newCity];
   
          setSelectedCity(newCity);
          return updatedList;
        }
        return prev;
      });

      window.history.replaceState({}, document.title);
    }
  }, [location.state]);


const handleRemoveCity = (e: React.MouseEvent, cityId: string) => {
    e.stopPropagation(); 
    if (cityId === "IST") return; 
    
    setCitiesList((prev) => prev.filter(c => c.id !== cityId));

    if (selectedCity.id === cityId) {
      setSelectedCity(cities[0]);
    }
  };

// city add 
const handleAddCity = (newCity: any) => {
  const isExist = citiesList.find(c => c.city === newCity.city);
  
  if (!isExist) {
    const cityWithData = {
      ...newCity,
 
      id: newCity.id || Math.random().toString(36).substr(2, 4).toUpperCase(),
      
     
      offset: newCity.offset || "GMT+0:00", 
      coords: newCity.coords || "0.00° N, 0.00° E",
      currency: newCity.currency || "Local Currency",
      language: newCity.language || "Local Language",
      dialing: newCity.dialing || "--",
      iana: newCity.timezone || "UTC",
      

      image: `https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80&q=${encodeURIComponent(newCity.city + " skyline")}&sig=${Math.random()}`,

      sunrise: newCity.sunrise || "06:00 AM",
      sunset: newCity.sunset || "06:00 PM",
      description: newCity.description || `${newCity.city} is a major city.`
    };

    setCitiesList(prev => [...prev, cityWithData]);
    setSelectedCity(cityWithData);
  }

  setIsSearchOpen(false);
  setSearchQuery("");
};
  const handlePrev = () => {
    const d = new Date(currentDate);
    d.setDate(d.getDate() - 1);
    setCurrentDate(d);
  };

  const handleNext = () => {
    const d = new Date(currentDate);
    d.setDate(d.getDate() + 1);
    setCurrentDate(d);
  };

const handleSearchSelection = async (item: any) => {
  setIsLoading(true);
  
  // Basic names extraction
  const cityName = item.address.city || item.address.town || item.address.village || item.display_name.split(',')[0];
  const countryName = item.address.country;
  const countryCode = item.address.country_code?.toUpperCase();

  try {
    // 1. Fetch Extra Details
    const countryRes = await fetch(`https://restcountries.com/v3.1/alpha/${countryCode}`);
    const countryData = await countryRes.json();
    const countryInfo = countryData[0];

    const currencyKey = Object.keys(countryInfo.currencies || {})[0];
    const currencyName = currencyKey ? countryInfo.currencies[currencyKey].name : "Local Currency";
    const languageName = Object.values(countryInfo.languages || {})[0] || "Local Language";
    const dialingCode = (countryInfo.idd.root || "") + (countryInfo.idd.suffixes?.[0] || "");
    
    const newCity: City = {
      id: cityName.slice(0, 3).toUpperCase() + Math.floor(Math.random() * 1000),
      city: cityName,
      country: countryName,
      countryCode: countryCode || "UN",
      timezone: "UTC", 
      offset: countryInfo.timezones?.[0] || "GMT+0:00", 
      coords: `${parseFloat(item.lat).toFixed(2)}° N, ${parseFloat(item.lon).toFixed(2)}° E`,
      currency: `${currencyName} (${currencyKey || '—'})`,
      language: languageName as string,
      dialing: dialingCode || "--",
      iana: countryInfo.timezones?.[0] || "UTC",
      sunrise: "06:00 AM",
      sunset: "06:30 PM",
      image: `https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&w=1200&q=80&sig=${cityName}`,
      description: `${cityName} is a vibrant city located in ${countryName}.`
    };

    setCitiesList((prev) => {
      if (prev.find((c) => c.city === newCity.city)) return prev;
      return [...prev, newCity];
    });
    setSelectedCity(newCity);

  } catch {
    // FALLBACK BLOCK FIX
    const fallbackCity: City = {
      id: cityName.slice(0, 3).toUpperCase() + Math.floor(Math.random() * 100),
      city: cityName,
      country: countryName,
      countryCode: countryCode || "UN",
      timezone: "UTC",
      offset: "GMT+0",
      coords: `${parseFloat(item.lat).toFixed(2)}° N, ${parseFloat(item.lon).toFixed(2)}° E`,
      currency: "N/A",
      language: "N/A",
      dialing: "--",
      iana: "UTC",
      sunrise: "06:00 AM",
      sunset: "06:00 PM",
      image: `https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&w=1200&q=80`,
      description: `${cityName} is a city in ${countryName}.`
    };
    
    setCitiesList((prev) => [...prev, fallbackCity]);
    setSelectedCity(fallbackCity);
  } finally {
    setIsLoading(false);
    setIsSearchOpen(false);
    setSearchQuery("");
  }
};

//   const handleCitySelect = async (cityData: any) => {
//   try {

//     const tzResponse = await fetch(`https://worldtimeapi.org/api/timezone/Etc/GMT${parseFloat(cityData.lon) >= 0 ? '-' : '+'}${Math.floor(Math.abs(parseFloat(cityData.lon)/15))}`);

    
//     const newCity = {
//       id: cityData.name.slice(0, 3).toUpperCase(),
//       city: cityData.name,
//       country: cityData.country,
//       countryCode: cityData.countryCode,
//       timezone: "UTC", 
//       offset: "GMT+0:00",
//       coords: `${parseFloat(cityData.lat).toFixed(2)}° N, ${parseFloat(cityData.lon).toFixed(2)}° E`,
//     };

//     handleAddCity(newCity);
//   } catch (e) {
//     handleAddCity({ ...cityData, timezone: "UTC" });
//   }
// };

  /* ===== LIVE TIME & PROGRESS ===== */
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const h = now.getHours();
      const m = now.getMinutes();
      const s = now.getSeconds();

      // setCurrentTime(
      //   `${h.toString().padStart(2, "0")}:${m
      //     .toString()
      //     .padStart(2, "0")}`
      // );

      const totalMinutes = h * 60 + m + s / 60;
      setProgress((totalMinutes / 1440) * 100);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen w-full bg-[#E9EDFA] dark:bg-[#0B1224] text-slate-800 dark:text-white">

      {/* ================= MAIN ================= */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 py-10 space-y-14">

        {/* Status */}
        <div className="flex justify-center">
          <div className="flex items-center  px-3 rounded-full bg-[rgb(var(--bg-card))] border">
           <span className="w-2 h-2 bg-[#676AF1] rounded-full mr-2"></span>
            <span className="text-gray-500 text-sm font-medium">
              SYNCHRONIZATION ACTIVE
            </span>
          </div>
        </div>

     

        {/* Title */}
      

          <div className="text-center max-w-5xl">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold">
              <span className="block">Global Time,</span>
              <span className="block text-purple-400 mt-2">Perfectly Aligned</span>
            </h1>
            <p className="mt-6 text-base sm:text-lg lg:text-xl text-[#758197]">
Seamlessly coordinate across time zones with our intelligent converter. Drag the slider to preview future meetings or track global markets in real-time.
            </p>

          </div>





   {/* ================= DATE SELECTOR ================= */}
<div className="flex justify-end items-center">
  <div className="flex items-center p-1 gap-1 rounded-2xl  dark:bg-white/5 bg-[#F8F9FD] border border-slate-200 dark:border-white/10 backdrop-blur-md shadow-sm">
    
    {/* Previous Day Button */}
    <button
      onClick={handlePrev}
      className="p-2.5 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-white dark:hover:bg-white/10 hover:text-indigo-600 dark:hover:text-white transition-all duration-200 group"
      title="Previous Day"
    >
      <ChevronLeft size={18} className="group-active:-translate-x-1 transition-transform" />
    </button>
{/* Date Navigation Section */}
<div className="flex items-center gap-1 sm:gap-2 ">
  
  

  {/* 2. Center Date Box (Calendar Trigger) */}
  <div className="relative flex items-center gap-2 sm:gap-3 px-3 sm:px-4 py-2 rounded-xl cursor-pointer  transition-colors group ">
    {/* Hidden Native Date Picker */}
    <input
      type="date"
      className="absolute inset-0 opacity-0 cursor-pointer z-10"
      style={{ colorScheme: 'dark' }} 
      onChange={(e) => {
        if (e.target.value) setCurrentDate(new Date(e.target.value));
      }}
      onClick={(e) => {
        if ('showPicker' in e.currentTarget) {
          try { e.currentTarget.showPicker(); } catch (err) {console.error(err);}
        }
      }}
    />

    {/* Calendar Icon */}
    <div className="p-1.5 rounded-lg text-indigo-600 dark:text-indigo-400">
      <Calendar size={16} />
    </div>
    
    {/* Formatted Date Text */}
    <span className="text-xs sm:text-sm font-bold tracking-tight text-slate-700 dark:text-slate-200 whitespace-nowrap">
      {currentDate.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric', 
        year: 'numeric' 
      })}
    </span>
  </div> 
</div>

    {/* Hidden Native Input */}
    <input
      id="date-picker"
      type="date"
      value={currentDate.toISOString().split("T")[0]}
      onChange={(e) => setCurrentDate(new Date(e.target.value))}
      className="absolute opacity-0 pointer-events-none w-0 h-0"
    />

    {/* Next Day Button */}
    <button
      onClick={handleNext}
      className="p-2.5 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-white dark:hover:bg-white/10 hover:text-indigo-600 dark:hover:text-white transition-all duration-200 group"
      title="Next Day"
    >
      <ChevronRight size={18} className="group-active:translate-x-1 transition-transform" />
    </button>
  </div>
</div>


        


       {/* ================= TIMELINE & OVERLAP ================= */}

<div className="p-6 md:p-10 rounded-[32px] border border-slate-200 dark:border-white/5 bg-[#F8F9FD] dark:bg-[#0b0e22] text-slate-500 dark:text-[#717696] shadow-xl transition-all duration-300">
  
  {/* --- Top Slider Section --- */}
  <div className="max-w-2xl mx-auto mb-10">
    <div className=" mr-10 ml-10 flex justify-between text-[13px] font-bold px-1 tracking-widest opacity-60 text-slate-500 dark:text-[#AFBACC]">
      <span>00:00</span>
      <span>12:00</span>
      <span>23:59</span>
    </div>

    {/* Main Progress Slider */}
    <div className="mt-10 relative h-1.5 group mr-10 ml-10">
      {/* Background Track */}
      <div className="absolute inset-0 flex justify-between items-center pointer-events-none px-1">
        {[...Array(13)].map((_, i) => (
          <div key={i} className="w-[1px] h-3 bg-slate-400 dark:bg-white/40" />
        ))}
      </div>
      <div className="absolute inset-0 bg-slate-100 dark:bg-white/10 rounded-full" />
      
      {/* Visual Progress Highlight */}
      <div 
        className="absolute h-full bg-[#D8DFF6] dark:bg-white/20 rounded-full pointer-events-none"
        style={{ width: `${progress}%` }}
      />

      {/* Range Input Overlay */}
      <input
        type="range" min="0" max="100" step="0.1" value={progress}
        onChange={(e) => setProgress(parseFloat(e.target.value))}
        className="absolute inset-0 w-full opacity-0 cursor-pointer z-20"
      />

      {/* Glowing Thumb Indicator */}
      <div
        className="absolute top-1/2 -translate-y-1/2 h-6 w-6 bg-[#6366F1] rounded-full shadow-lg dark:shadow-[0_0_20px_rgba(99,102,241,0.8)] border-[3px] border-white dark:border-[#0b0e22] pointer-events-none transition-all duration-300"
        style={{ left: `calc(${progress}% - 12px)` }}
      />
    </div>

    {/* Live Clock Button */}
    <div className="flex justify-center mt-10">
  <button
    onClick={() => setIsPaused(!isPaused)}
    className={`
      flex items-center gap-2.5 px-6 py-2.5 rounded-full 
      text-[10px] font-black tracking-[0.2em] uppercase transition-all duration-500
      border shadow-sm group
      ${isPaused
        ? "bg-slate-100 dark:bg-white/5 text-slate-400 dark:text-white/60 border-slate-200 dark:border-white/10"
        : "bg-emerald-50 dark:bg-[#10b981]/10 text-emerald-600 dark:text-[#10b981] border-emerald-200 dark:border-[#10b981]/30"
      }
    `}
  >
    {isPaused ? (
      /* Play Icon when Paused */
      <div className="relative flex items-center justify-center">
        <Play size={12} fill="currentColor" className="ml-0.5" />
      </div>
    ) : (
      /* Activity Pulse Icon when Live */
      <div className="relative flex items-center justify-center">
        {/* Animated outer ring for 'Live' feel */}
        <span className="absolute inset-0 rounded-full bg-emerald-500 animate-ping opacity-20"></span>
        <Pause size={14} className="relative z-10" />
      </div>
    )}
    
    <span className="relative">
      {isPaused ? "Paused" : "Live Clock"}
    </span>
  </button>
</div>
  </div>
  {/* ================= DIVIDER ================= */}
<div className="relative py-4">
  <div className="absolute inset-0 flex items-center" aria-hidden="true">
    <div className="w-full border-t border-slate-300 dark:border-white/10"></div>
  </div>
</div>

  {/* --- Timeline Header --- */}
  <div className="flex items-center gap-2 mb-8 mt-6">
    <span className="text-indigo-500 text-sm font-bold">...</span>
    <h3 className="text-[13px] font-black tracking-[0.25em] text-slate-400 dark:text-white/80 uppercase">
      Timeline & Overlap
    </h3>
  </div>

  {/* Time Labels for Rows */}
  <div className="flex justify-between text-[11px] pl-[72px] pr-2 opacity-90 font-bold mb-4 text-slate-500 dark:text-[#717696]">
    <span>00:00</span>
    <span>06:00</span>
    <span>12:00</span>
    <span>18:00</span>
    <span>23:00</span>
  </div>

 {/* Timezone Rows */}
<div className="relative space-y-4">
  {citiesList.map((city) => {

    const getCityProgress = (timezone: string) => {
      const now = new Date(new Date().toLocaleString("en-US", { timeZone: timezone }));
      const h = now.getHours();
      const m = now.getMinutes();
      return ((h * 60 + m) / 1440) * 100;
    };

    const cityProgress = getCityProgress(city.timezone);

    return (
      <div key={city.id} className="group flex items-center gap-6">
        {/* City ID Label (e.g., IST, EST) */}
        <span className="w-12 text-[11px] font-black text-slate-600 dark:text-white/70 tracking-tighter shrink-0">
          {city.id}
        </span>

        {/* Timeline Track divided into 24 Chunks */}
        <div className="relative flex-1 h-9 rounded-md overflow-hidden bg-slate-100 dark:bg-[#161a35] border border-slate-200 dark:border-transparent flex group/track">
          
{/* 2. ULTIMATE: Floating Capsule Glass Thumb */}
<div 
  className="absolute z-30 flex flex-col items-center transition-all duration-300 ease-out pointer-events-auto h-[120%] -top-[10%]"
  style={{ 
    left: `${cityProgress}%`,
    transform: 'translateX(-50%)',
  }}
>
  {/* Glass Capsule Body */}
  <div className="
    relative h-full w-[26px] 
    bg-gray-300 dark:bg-slate-700/60 
    backdrop-blur-xl
    rounded-full 
    shadow-[0_8px_32px_0_rgba(31,38,135,0.2)]
    dark:shadow-[0_8px_32px_0_rgba(0,0,0,0.6)]
    border border-white/40 dark:border-white/10
    flex flex-col items-center justify-between py-2
    group/thumb hover:w-[32px] hover:scale-y-105
    transition-all cursor-grab active:cursor-grabbing
  ">
    
    {/* Decorative Top Accent */}
    <div className="w-1.5 h-1.5 rounded-full bg-indigo-500/50 dark:bg-indigo-400/50" />

    {/* Center Dynamic Grip - Moves on Hover */}
    <div className="flex flex-col gap-1 group-hover/thumb:gap-1.5 transition-all">
      <div className="w-[3px] h-[3px] rounded-full bg-indigo-500 shadow-[0_0_8px_#6366f1]" />
      <div className="w-[3px] h-[3px] rounded-full bg-indigo-500 shadow-[0_0_8px_#6366f1]" />
      <div className="w-[3px] h-[3px] rounded-full bg-indigo-500 shadow-[0_0_8px_#6366f1]" />
    </div>

    {/* Decorative Bottom Accent */}
    <div className="w-1.5 h-1.5 rounded-full bg-indigo-500/50 dark:bg-indigo-400/50" />

    {/* Floating Time Label (Savvy-Premium Style) */}
    <div className="
      absolute -top-10 
      bg-slate-900 dark:bg-indigo-600
      text-white text-[10px] font-black tracking-tighter
      px-2.5 py-1 rounded-full
      opacity-0 group-hover/thumb:opacity-100 
      scale-50 group-hover/thumb:scale-100
      transition-all duration-300
      shadow-[0_10px_20px_rgba(0,0,0,0.3)]
      border border-white/20
    ">
        {new Date(new Date().toLocaleString("en-US", { timeZone: city.timezone })).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
    </div>

    {/* Inner Subtle Glow Effect */}
    <div className="absolute inset-0 rounded-full bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />
  </div>

  {/* Bottom Glow Point */}
  <div className="w-1 h-1 bg-indigo-500 rounded-full blur-[2px] mt-1 opacity-0 group-hover/thumb:opacity-100 transition-opacity" />
</div>
          {/* 3. Generating 24 Horizontal Chunks */}
          {[...Array(24)].map((_, hour) => {
            // Color logic: Night, Morning, Business, Evening
            let bgColor = "bg-slate-200 dark:bg-[#1c2242]"; // Night (Default)
            if (hour >= 6 && hour < 9) bgColor = "bg-indigo-50 dark:bg-[#242b57]"; 
            if (hour >= 9 && hour < 18) bgColor = "bg-indigo-100 dark:bg-[#303975]"; 
            if (hour >= 18 && hour < 21) bgColor = "bg-indigo-50 dark:bg-[#242b57]"; 

            return (
              <div 
                key={hour} 
                className={`flex-1 h-full border-r border-white/5 last:border-0 ${bgColor} transition-colors duration-300 relative`}
              >

                <div className="absolute inset-0 opacity-0 group-hover/track:hover:opacity-20 bg-white pointer-events-none" />
              </div>
            );
          })}
        </div>
      </div>
    );
  })}
</div>

  {/* Legend */}
  <div className="flex flex-wrap justify-center gap-6 md:gap-10 mt-12 text-[9px] font-black tracking-[0.15em] uppercase text-slate-500 dark:text-white/40">
    <div className="flex items-center gap-2.5">
      <div className="w-2.5 h-2.5 rounded-full bg-indigo-200 dark:bg-[#303975]" /> BUSINESS HOURS
    </div>
    <div className="flex items-center gap-2.5">
      <div className="w-2.5 h-2.5 rounded-full bg-indigo-200 dark:bg-[#242b57]" /> DAY HOURS
    </div>
    <div className="flex items-center gap-2.5">
      <div className="w-2.5 h-2.5 rounded-full bg-indigo-200 dark:bg-[#1c2242]" /> NIGHT
    </div>
  </div>

  {/* ================= CITY CARDS GRID ================= */}
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 mt-10">
  {citiesList.map((city) => {
    const { time, hour } = getCityTime(city.timezone);
    const isPrimary = city.id === "IST" || city.city.includes("New Delhi");
    const isSelected = selectedCity.id === city.id;

    return (
      <div
        key={city.id}
        onClick={() => setSelectedCity(city)}
        className={`group relative cursor-pointer p-5 rounded-2xl border transition-all duration-500 flex flex-col justify-between overflow-hidden
          ${isSelected
            ? "border-indigo-500 bg-indigo-50/50 dark:bg-indigo-500/10 shadow-[0_10px_30px_-10px_rgba(99,102,241,0.4)] scale-[1.02]"
            : "border-slate-200 bg-white dark:border-white/5 dark:bg-[#0f172a] hover:border-indigo-400 hover:shadow-xl hover:-translate-y-1"
          }`}
        style={{ minHeight: "200px" }}
      >

        {!isPrimary && (
          <button
            onClick={(e) => handleRemoveCity(e, city.id)}
            className="absolute top-2 right-2 z-30 p-1.5 rounded-full bg-slate-100/50 dark:bg-white/5 text-red-400 dark:hover:text-red-400  hover:text-red-400 hover:text-white transition-all duration-300 opacity-0 group-hover:opacity-100 shadow-sm"
          >
            <X size={12} strokeWidth={3} />
          </button>
        )}

        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/0 via-transparent to-indigo-500/0 group-hover:from-indigo-500/[0.03] transition-all duration-500" />

        {/* Top Header Section */}
        <div className="flex justify-between items-start relative z-10">
           <div className="flex items-center gap-2 overflow-hidden mr-6"> {/* mr-6 to give space for X button */}
             <span className="text-[14px] font-black text-slate-500 dark:text-gray-600 uppercase">
               {city.countryCode || (city.id === "IST" ? "IN" : city.id.slice(0, 2))}
             </span>
             <div className="flex flex-col min-w-0">
               <span className="text-[15px] font-bold text-indigo-600 dark:text-indigo-400 uppercase leading-none mb-1">
                 {city.id}
               </span>
              <div className="flex items-center gap-2">
    {/* City Name */}
    <span className="text-[12px] text-slate-500 dark:text-gray-400 font-medium truncate">
      {city.city},
    </span>

    {/* Country "Button" Style Bordered Box */}
    <div className="px-2 py-0.5 border border-white/10 bg-white/5 rounded-md flex-shrink-0">
      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
        {city.country}
      </span>
    </div>
  </div>

             </div>
           </div>
           
           {/* Sun/Moon Icon: Positioned slightly lower to avoid X button overlap */}
           <span className="mt-1">
             {hour >= 6 && hour <= 18 
               ? <Sun size={20} className="text-amber-500 mt-4 drop-shadow-[0_0_8px_rgba(245,158,11,0.3)]" /> 
               : <Moon size={20} className="text-indigo-400 mt-4 drop-shadow-[0_0_8px_rgba(129,140,248,0.3)]" />
             }
           </span>
        </div>

        {/* Middle Section: Big Time */}
        <div className="mt-4 relative z-10">
          <h2 className="text-3xl font-black text-slate-900 dark:text-white">
            {time.split(' ')[0]} <span className="text-[10px] font-bold text-slate-400">{time.split(' ')[1]}</span>
          </h2>
          <p className="text-[11px] font-bold text-slate-400 mt-0.5 uppercase tracking-wide">
            {new Date().toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", timeZone: city.timezone })}
          </p>
        </div>

        <div className="flex justify-end items-end h-5 relative z-10">
          {isPrimary && (
            <span className="bg-indigo-600 text-[9px] font-black text-white px-2 py-0.5 rounded-md uppercase tracking-widest shadow-md">
              Primary
            </span>
          )}
        </div>
      </div>
    );
  })}
  
  {/* ================= ADD CITY CARD / SEARCH DROPDOWN ================= */}
<div className="relative h-full">
  {!isSearchOpen ? (
    /* Initial Add City Card */
    <div 
      onClick={() => setIsSearchOpen(true)}
      className="h-[200px] flex-shrink-0 group cursor-pointer h-full p-4 flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-300 dark:border-white/10 text-slate-400 dark:text-white/20 hover:border-indigo-500 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-500/5 transition-all duration-300"
      style={{ minHeight: "200px" }}
    >
      <div className="w-10 h-10 rounded-full border-2 border-solid border-current flex items-center justify-center mb-3 group-hover:scale-110 transition-all duration-500">
        <Plus size={24} strokeWidth={2.5} />
      </div>
      <p className="font-bold text-[10px] uppercase tracking-widest">Add City</p>
    </div>
  ) : (
    /* Search Dropdown Card after Click */
    <div 
      className="h-full p-5 rounded-2xl border-2 border-indigo-500 bg-white dark:bg-[#0f172a] shadow-[0_10px_30px_-10px_rgba(99,102,241,0.4)] transition-all duration-300 flex flex-col"
      style={{ minHeight: "200px" }}
    >
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-white/10 pb-2 mb-3">
        <Search size={16} className="text-indigo-500" />
        <input 
          autoFocus
          type="text"
          placeholder="Search city..."
          className="w-full bg-transparent outline-none text-sm font-medium dark:text-white placeholder:text-slate-400"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <button 
          onClick={() => { setIsSearchOpen(false); setSearchQuery(""); }}
          className="p-1 hover:bg-red-50 dark:hover:bg-red-500/10 rounded-full text-slate-400 hover:text-red-500 transition-colors"
        >
          <X size={16} />
        </button>
      </div>
      
      {/* Dropdown Results List */}
   <div className="flex-1 overflow-y-auto custom-scrollbar space-y-1 pr-1">
  {isLoading && (
    <div className="flex justify-center py-4">
      <div className="w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
    </div>
  )}

  {!isLoading && searchResults.map((result, idx) => (
    <div 
      key={idx}
      onClick={() => handleSearchSelection(result)}
      className="group/item flex flex-col px-3 py-2 hover:bg-indigo-600 hover:text-white rounded-xl cursor-pointer transition-all border border-transparent hover:border-indigo-400"
    >
      <div className="flex justify-between items-center">
        <span className="font-bold text-[13px]">{result.name}</span>
        <Plus size={14} className="opacity-0 group-hover/item:opacity-100 transition-opacity" />
      </div>
      <span className="text-[10px] opacity-60 truncate group-hover/item:text-indigo-100">
        {result.country}
      </span>
    </div>
  ))}
  
  {!isLoading && searchQuery.length > 2 && searchResults.length === 0 && (
    <div className="text-center py-4">
      <p className="text-[11px] text-slate-400 font-medium">No results found</p>
    </div>
  )}
</div>
    </div>
  )}
</div>
</div>
</div>

 {/* ================= DETAILS PANEL ================= */}
{selectedCity && (
  <div
    className="
      relative
      rounded-3xl
      p-8
      border
      border-slate-200 dark:border-white/10
      bg-[#FDFDFE] dark:bg-[#0B1224]
      text-slate-900 dark:text-white
      overflow-hidden
      transition-colors
      shadow-xl
    "
  >
    {/* Header */}
    <p className="flex items-center font-semibold gap-2 text-xs uppercase text-[#94A3B8] dark:text-blue-300">
      <MapPin size={14} />
      Location Standard Time Details
    </p>

    {/* Title */}
    <h2 className="text-3xl font-semibold mt-2">
      {selectedCity.city}
      <span className="text-[#6366F1] dark:text-blue-300 text-sm ml-2">
        {selectedCity.country}
      </span>
    </h2>

    <p className="text-[#6366F1] font-semibold dark:text-blue-200 text-sm mt-1">
      {selectedCity.country} Standard Time
    </p>

    {/* Content */}
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
      {/* Info Cards */}
<div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
  {[
    { label: "Offset", value: selectedCity.offset ?? "—", icon: <Clock size={12} className="text-slate-400" /> },
    { label: "Coords", value: selectedCity.coords ?? "—", icon: <MapPin size={12} className="text-slate-400" /> },
    { label: "Currency", value: selectedCity.currency ?? "—", icon: <Banknote size={12} className="text-slate-400" /> },
    { label: "Language", value: selectedCity.language ?? "—", icon: <Languages size={12} className="text-slate-400" /> },
    { label: "Dialing", value: selectedCity.dialing ?? "—", icon: <Phone size={12} className="text-slate-400" /> },
    { label: "IANA ID", value: selectedCity.iana ?? selectedCity.timezone, icon: <Globe size={12} className="text-slate-400" /> },
  ].map(({ label, value, icon }) => (
    <div
      key={label}
      className="
        rounded-xl
        bg-slate-50 dark:bg-white/5
        border
        border-slate-200 dark:border-white/10
        px-4
        py-3
        transition-all
        hover:border-indigo-500/40
        group
      "
    >
      <div className="flex items-center gap-2 mb-1.5">
        {icon}
        <p className="text-[10px] text-slate-400 dark:text-blue-300 uppercase font-black tracking-wider">
          {label}
        </p>
      </div>
      <p className="text-sm font-bold text-slate-800 dark:text-slate-100">{value}</p>
    </div>
  ))}

  {/* Exact Sunrise / Sunset Icons with Video Styling */}
  {(selectedCity.sunrise || selectedCity.sunset) && (
    <div className="col-span-full flex gap-12 mt-4">
      <div className="flex items-center gap-3">
        <Sunrise 
          size={24} 
          className="text-amber-500 drop-shadow-[0_0_8px_rgba(245,158,11,0.4)]" 
        />
        <div>
          <p className="text-[9px] text-slate-400 dark:text-blue-300 uppercase font-black tracking-[0.1em]">
            Sunrise
          </p>
          <p className="text-sm font-bold">
            {selectedCity.sunrise ?? "—"}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Sunset 
          size={24} 
          className="text-indigo-500 drop-shadow-[0_0_8px_rgba(99,102,241,0.4)]" 
        />
        <div>
          <p className="text-[9px] text-slate-400 dark:text-blue-300 uppercase font-black tracking-[0.1em]">
            Sunset
          </p>
          <p className="text-sm font-bold">
            {selectedCity.sunset ?? "—"}
          </p>
        </div>
      </div>
    </div>
  )}
</div>

    
{/* --- 1. Description + Divider Container --- */}
{selectedCity.description && (
  <div className="
    order-1          
    lg:order-2       
    col-span-full lg:col-span-2
    mt-6
  ">
    
    <div className="w-full border-t border-slate-200 dark:border-white/10 mb-6" />

    <p className="text-sm text-slate-500 dark:text-blue-200 max-w-4xl leading-relaxed italic">
      {selectedCity.description}
    </p>
  </div>
)}

{/* --- 2. Image (Desktop: Side, Mobile: Bottom) --- */}
<div className="
  relative 
  rounded-2xl 
  overflow-hidden 
  border 
  border-slate-200 dark:border-white/10 
  order-2 lg:order-1
  lg:row-span-1    /* Image ab sirf info cards waali row tak rahega */
  h-full
  min-h-[300px]
  max-h-[350px]
">
  <img
    src={selectedCity.image ?? "https://images.unsplash.com/photo-1587474260584-136574528ed5"}
    alt={selectedCity.city}
    className="h-full w-full object-cover"
  />
  <div className="absolute bottom-0 left-0 right-0  p-4">
    <p className="text-xs uppercase text-white">Location View</p>
    <p className="font-semibold text-lg text-white">{selectedCity.city}</p>
  </div>
</div>
    </div>
  </div>
)}
      </main>




      {/* ================= FOOTER ================= */}
      <footer
        className="
    mt-20
   border-t border-slate-300
  
  "
      >
        <div
          className="
      max-w-7xl
      mx-auto
      px-4
      py-12
      flex
      flex-col
      items-center    
      justify-center  
      text-center     
      gap-4
      text-sm
      text-[rgb(var(--text-muted))]
      md:flex-row     /* Desktop layout */
    "
        >
          <div className="flex-1">
            <p className="text-sm text-gray-500 mt-1">
              © 2026 ChronoSync. Premium Global Time Utilities.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}




