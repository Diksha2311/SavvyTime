// components/Navbar.tsx
import { useState, useEffect } from "react"; 
import { Sun, Moon, Settings, Globe } from "lucide-react";

export default function Navbar() {
  const [darkMode, setDarkMode] = useState(true); 

  // Initial Check: Page load hote hi check karega
  useEffect(() => {
    const isDark = document.documentElement.classList.contains("dark");
    setDarkMode(isDark);
  }, []);

  const toggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    
    if (newMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  };

  return (
    <nav className="w-full h-16 sm:h-20 z-50 flex justify-between items-center px-4 sm:px-8 dark:bg-[#0B1224] bg:FBFCFD]">
      {/* Left: Logo */}
      <div className="flex items-center gap-2 sm:gap-3">
        <div className="w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-md bg-gradient-to-br from-purple-400 via-purple-500 to-purple-600 ">
          <Globe className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
        </div>
        <div className="text-lg sm:text-xl font-bold">
          <span className="text-[rgb(var(--text-main))]">Chrono</span>
          <span className="text-purple-400">Sync</span>
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2 sm:gap-4">
        {/* Toggle Icon Logic */}
        <button onClick={toggleDarkMode} className="p-2 rounded transition-colors">
        
          {darkMode ? (
            <Sun className="w-5 h-5 text-gray-400 hover:text-white transition-colors" />
          ) : (
            <Moon className="w-5 h-5 text-slate-600 hover:text-slate-900 transition-colors" />
          )}
        </button>

        <button className="p-2 rounded transition-colors">
          <Settings className={`w-5 h-5 text-[rgb(var(--text-muted))] hover:text-purple-400 transition-colors`} />
        </button>
      </div>
    </nav>
  );
}














