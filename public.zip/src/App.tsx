import { BrowserRouter as Router, Routes, Route,useNavigate,useLocation } from 'react-router-dom'
import { useEffect } from 'react'
import './App.css'
import Navbar from './components/Navbar'
import Home from './components/Home'
import CityUi from './components/CityUi'



function RefreshHandler() {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {

    if (location.pathname !== '/') {
      navigate('/', { replace: true });
    }
  }, []); 

  return null;
}

function App() {
  
  useEffect(() => {

    const savedTheme = localStorage.getItem('theme');
    

    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  return (
    <Router>
      <RefreshHandler />

      <div className="min-h-screen bg-white dark:bg-[#020617] transition-colors duration-300">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/city" element={<CityUi />} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export default App;

