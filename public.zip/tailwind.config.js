/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class', // Yeh line hona zaruri hai
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        darkBg: '#131A2E', // Aapka bataya gaya color
      }
    },
  },
  plugins: [],
}

